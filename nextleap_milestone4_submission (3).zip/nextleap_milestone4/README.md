# Review Pulse & Fee Clarity — ChatGPT Mobile Voice Input

A lightweight prototype for the NextLeap RAGs & Context Engineering milestone.

## What it does
- Loads a CSV of public review excerpts from `data/reviews_sample.csv`.
- Groups review signals into three themes.
- Generates a weekly product pulse and reusable fee/plan clarification.
- Requires an explicit approval click before enabling the simulated “Append to Notes” and “Create Email Draft” actions.
- After approval, lets the user download a JSON notes entry and an email draft. It does not auto-send email.

## Run locally
Python 3.10+ recommended.

```bash
python -m http.server 8000
```
Then open `http://localhost:8000` (from this project folder).

No API key is required. This is a deterministic demo using a prepared review CSV and pre-generated analysis, so the output is reproducible.

## MCP / approval gating
This prototype demonstrates an approval gate in the UI. Before approval, the append and draft actions are disabled. After approval, the UI enables download of:
- `weekly_product_pulse.json` (the structured note payload)
- `email_draft.txt` (the draft content)

**Integration status:** The prototype simulates the approval-gated workflow and produces artifacts; it does not connect to a live Google Doc/Notion or Gmail account, and it does not call a live MCP server. To complete a live integration, connect an MCP server/tool for Docs/Notion and Gmail, then map the approved JSON and draft to those tools. No email is sent.

## Identified fee issue
Public reviews indicate confusion about plan limits and upgrade prompts, with a related support risk of misunderstanding subscription charges across platforms. The explainer uses official OpenAI Help Center sources. A usage limit is not itself proof that a purchase occurred.

## Data limitations
The included CSV contains three real, dated public review excerpts surfaced on Google Play (15 Aug, 5 Sep, 6 Sep 2026). This is a small sample and **not** a comprehensive 8–12-week review export. Quotes are real excerpts and are attributed by source/date; one reviewer display name was not available in the captured snippet. Expand the dataset before claiming representative trends.

## Sources
See `SOURCES.md`.

## Files
- `data/reviews_sample.csv`
- `outputs/weekly_product_pulse.md`
- `outputs/weekly_product_pulse.json`
- `outputs/fee_explainer.json`
- `outputs/email_draft.txt`
- `index.html`
