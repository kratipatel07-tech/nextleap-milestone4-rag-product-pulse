# Sources (official + public review listing)

1. Google Play — ChatGPT Android app and public user reviews (review excerpts dated 15 Aug, 5 Sep, and 6 Sep 2026 as surfaced in the listing/search result):
   https://play.google.com/store/apps/details?id=com.openai.chatgpt
2. OpenAI Help Center — Avoid duplicate charges across iOS, Android, and web:
   https://help.openai.com/en/articles/20001043-how-do-i-avoid-being-charged-twice-if-i-subscribe-to-chatgpt-on-ios-android-and-the-web
3. OpenAI Help Center — Canceling your ChatGPT subscription:
   https://help.openai.com/en/articles/7232927-canceling-your-chatgpt-subscription
4. OpenAI Help Center — ChatGPT iOS app: Upgrading to a paid subscription:
   https://help.openai.com/en/articles/7905739-chatgpt-ios-app-upgrading-to-a-paid-subscription
5. OpenAI Help Center — Managing billing for ChatGPT and the API platform:
   https://help.openai.com/en/articles/9039756-managing-billing-for-chatgpt-and-the-api-platform
6. OpenAI — ChatGPT pricing:
   https://openai.com/chatgpt/pricing

Review dataset note: reviews_sample.csv includes three real public excerpts visible on the Google Play listing/search results. Because only three recent dated reviews were captured in this prototype, the analysis is explicitly labeled as a small illustrative sample. Do not represent it as a comprehensive 8–12-week scrape.
